ADARSH DESIGNER — AURA BEAUTY SALON DEMO

FILES
- index.html: page structure and content
- style.css: premium responsive styling and animations
- script.js: mobile menu, reveal effects and WhatsApp appointment form
- assets/salon-hero.webp: generated hero image

HOW TO PREVIEW
Open index.html in a browser, or upload the complete folder contents to a GitHub Pages repository.

IMPORTANT CUSTOMISATION BEFORE SHOWING A REAL CLIENT
1. Replace “Aura Beauty Salon” with the actual salon name.
2. Replace the sample service descriptions and add real prices if the client provides them.
3. Replace the sample testimonial with a genuine review or remove that section.
4. In script.js, replace 91XXXXXXXXXX with the salon's WhatsApp number (country code + number, digits only).
5. In index.html, replace the sample meta description, title, and any placeholder contact details.
6. Replace the sample gallery photos with photos the salon has permission to use.

BRANDING
The footer credits “Adarsh Designer”. The salon name “Aura Beauty Salon” is a demo brand, not a real client claim.
External Google Fonts and Unsplash images need an internet connection. The hero image is included locally.
